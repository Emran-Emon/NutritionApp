import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'camera_overlay_screen.dart';

class PersonalInfoScreen extends StatefulWidget {
  @override
  _PersonalInfoScreenState createState() => _PersonalInfoScreenState();
}

class _PersonalInfoScreenState extends State<PersonalInfoScreen> {
  String selectedGoal = 'Maintain Weight';
  String caloriesNeeded = '';

  // Goals list
  final List<String> goals = ['Maintain Weight', 'Fat Loss', 'Weight Gain'];

  Future<String?> _getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('jwt_token');
  }

  Future<void> _fetchCalories() async {
    String? token = await _getToken();
    if (token == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: No token found. Please log in again.')),
      );
      return;
    }

    final response = await http.post(
      Uri.parse('https://firstly-popular-bunny.ngrok-free.app/calculate_calories'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({'goal': selectedGoal}),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      setState(() {
        caloriesNeeded = '${data['calories_needed']} kcal';
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to calculate calories: ${response.body}')),
      );
    }
  }

  void _openCameraOverlay() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CameraOverlayScreen(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Caloric Needs'),
          automaticallyImplyLeading: true,
        actions: [
          IconButton(
            icon: Icon(Icons.camera_alt),
            onPressed: _openCameraOverlay,
          ),
        ],
      ),
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/image.png'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Calories Needed for $selectedGoal: $caloriesNeeded',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 10),
                Text("Select Goal"),
                DropdownButton<String>(
                  value: selectedGoal,
                  onChanged: (String? newValue) {
                    setState(() {
                      selectedGoal = newValue!;
                    });
                  },
                  items: goals.map<DropdownMenuItem<String>>((String goal) {
                    return DropdownMenuItem<String>(
                      value: goal,
                      child: Text(goal),
                    );
                  }).toList(),
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: _fetchCalories,
                  child: Text('Calculate Calories'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
