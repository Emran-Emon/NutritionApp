import 'package:flutter/material.dart';
import 'camera_overlay_screen.dart';
import 'auth_service.dart';

class CalorieDisplayScreen extends StatefulWidget {
  @override
  _CalorieDisplayScreenState createState() => _CalorieDisplayScreenState();
}

class _CalorieDisplayScreenState extends State<CalorieDisplayScreen> {
  final TextEditingController _heightController = TextEditingController();
  final TextEditingController _weightController = TextEditingController();
  String _goal = 'Maintain Weight';
  String _caloriesNeeded = '';
  String userEmail = 'User Email';

  @override
  void initState() {
    super.initState();
    _getUserEmail();
  }

  Future<void> _getUserEmail() async {
    final user = AuthService.getCurrentUser();
    if (user != null) {
      setState(() {
        userEmail = user.email ?? 'Unknown Email';
      });
    }
  }

  void _calculateCalories() {
    double height = double.tryParse(_heightController.text) ?? 0;
    double weight = double.tryParse(_weightController.text) ?? 0;

    if (_goal == 'Maintain Weight') {
      _caloriesNeeded = '${10 * weight + 6.25 * height - 5 * 25} kcal';
    } else if (_goal == 'Fat Loss') {
      _caloriesNeeded = '${0.8 * (10 * weight + 6.25 * height - 5 * 25)} kcal';
    } else {
      _caloriesNeeded = '${1.2 * (10 * weight + 6.25 * height - 5 * 25)} kcal';
    }

    setState(() {});
  }

  void _openCamera() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => CameraOverlayScreen()),
    );
  }

  void _logout() async {
    await AuthService.logout();
    Navigator.pushReplacementNamed(context, '/');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Calorie Calculator'),
        automaticallyImplyLeading: true,
        actions: [
          PopupMenuButton<String>(
            icon: CircleAvatar(
              backgroundColor: Colors.grey,
              child: Text(
                userEmail.isNotEmpty ? userEmail[0].toUpperCase() : '?',
                style: TextStyle(color: Colors.white),
              ),
            ),
            onSelected: (value) {
              if (value == 'logout') {
                _logout();
              }
            },
            itemBuilder: (BuildContext context) => [
              PopupMenuItem<String>(
                value: 'email',
                child: Text(userEmail),
                enabled: false,
              ),
              PopupMenuItem<String>(
                value: 'logout',
                child: Text('Logout'),
              ),
            ],
          ),
        ],
      ),
      body: Stack(
        children: [
          // Background image
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assets/image.png"), // Ensure this path matches your assets
                fit: BoxFit.cover,
              ),
            ),
          ),
          // Semi-transparent overlay to improve text visibility
          Container(
            color: Colors.black.withOpacity(0.6),
          ),
          // Main content
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(16.0),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.8),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Column(
                      children: [
                        TextField(
                          controller: _heightController,
                          decoration: InputDecoration(
                            labelText: 'Height (cm)',
                            filled: true,
                            fillColor: Colors.white.withOpacity(0.9),
                            border: OutlineInputBorder(),
                          ),
                          keyboardType: TextInputType.number,
                        ),
                        SizedBox(height: 10),
                        TextField(
                          controller: _weightController,
                          decoration: InputDecoration(
                            labelText: 'Weight (kg)',
                            filled: true,
                            fillColor: Colors.white.withOpacity(0.9),
                            border: OutlineInputBorder(),
                          ),
                          keyboardType: TextInputType.number,
                        ),
                        SizedBox(height: 10),
                        DropdownButton<String>(
                          value: _goal,
                          onChanged: (String? value) {
                            setState(() {
                              _goal = value!;
                            });
                          },
                          items: ['Maintain Weight', 'Fat Loss', 'Weight Gain']
                              .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                              .toList(),
                          dropdownColor: Colors.white,
                        ),
                        SizedBox(height: 10),
                        ElevatedButton(
                          onPressed: _calculateCalories,
                          child: Text('Calculate Calories'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.orange,
                            padding: EdgeInsets.symmetric(
                              horizontal: 50,
                              vertical: 15,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                        SizedBox(height: 20),
                        Text(
                          'Calories Needed: $_caloriesNeeded',
                          style: TextStyle(fontSize: 16, color: Colors.white),
                        ),
                        SizedBox(height: 20),
                        ElevatedButton.icon(
                          onPressed: _openCamera,
                          icon: Icon(Icons.camera),
                          label: Text('Capture Your Food'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue,
                            padding: EdgeInsets.symmetric(
                              horizontal: 20,
                              vertical: 15,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
