import 'package:flutter/material.dart';
import 'login_screen.dart';
import 'calorie_display_screen.dart';
import 'signup_screen.dart';
import 'profile_info_screen.dart';
import 'package:firebase_core/firebase_core.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(NutritionApp());
}

class NutritionApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Nutrition App',
      theme: ThemeData(
        primarySwatch: Colors.orange,
        scaffoldBackgroundColor: Colors.black,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => LoginScreen(),
        '/signup': (context) => SignupScreen(),
        '/calories': (context) => CalorieDisplayScreen(),
        '/profile': (context) => ProfileInfoScreen(),
      },
    );
  }
}
