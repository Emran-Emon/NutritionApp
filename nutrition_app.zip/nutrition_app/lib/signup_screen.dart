import 'package:flutter/material.dart';
import 'auth_service.dart';

class SignupScreen extends StatefulWidget {
  @override
  _SignupScreenState createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  String? uid;

  void _signupWithGoogle() async {
    String? userId = await AuthService.googleSignIn();
    if (userId != null) {
      setState(() {
        uid = userId;
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Google Sign-Up Failed')),
      );
    }
  }

  void _completeRegistration() async {
    if (uid == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please sign in with Google first.')),
      );
      return;
    }

    String username = _usernameController.text.trim();
    String password = _passwordController.text.trim();

    if (username.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Username and Password cannot be empty.')),
      );
      return;
    }

    bool success =
    await AuthService.completeRegistration(uid!, username, password);
    if (success) {
      Navigator.pushReplacementNamed(context, '/calories');
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to complete registration.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Sign Up'),
          automaticallyImplyLeading: true,),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            ElevatedButton.icon(
              onPressed: _signupWithGoogle,
              icon: Icon(Icons.login),
              label: Text('Sign Up with Google'),
            ),
            if (uid != null) ...[
              TextField(
                controller: _usernameController,
                decoration: InputDecoration(labelText: 'Username'),
              ),
              TextField(
                controller: _passwordController,
                decoration: InputDecoration(labelText: 'Password'),
                obscureText: true,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _completeRegistration,
                child: Text('Complete Registration'),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
