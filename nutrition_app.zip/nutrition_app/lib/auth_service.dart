import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AuthService {
  static final FirebaseAuth _auth = FirebaseAuth.instance;
  static final GoogleSignIn _googleSignIn = GoogleSignIn();

  // Method for logging in with email and password
  static Future<bool> login(String email, String password) async {
    try {
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      return userCredential.user != null;
    } catch (e) {
      print("Login Error: $e");
      return false;
    }
  }

  // Method for signing up with Google
  static Future<String?> googleSignIn() async {
    try {
      // Sign out any previously logged-in account to prompt user selection
      await _googleSignIn.signOut();

      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      if (googleUser == null) {
        return null; // User canceled the sign-in
      }

      final GoogleSignInAuthentication googleAuth = await googleUser.authentication;

      final AuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      UserCredential userCredential = await _auth.signInWithCredential(credential);

      if (userCredential.user != null) {
        return userCredential.user?.uid;
      } else {
        return null;
      }
    } catch (e) {
      print("Google Sign-In Error: $e");
      return null;
    }
  }

  // Method to complete registration by adding username and password
  static Future<bool> completeRegistration(String uid, String username, String password) async {
    const String apiUrl = 'https://firstly-popular-bunny.ngrok-free.app/complete-registration';
    try {
      final response = await http.post(
        Uri.parse(apiUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'uid': uid,
          'username': username,
          'password': password,
        }),
      );

      if (response.statusCode == 200) {
        return true;
      } else {
        print("Failed to complete registration: ${response.body}");
        return false;
      }
    } catch (e) {
      print("Error completing registration: $e");
      return false;
    }
  }

  // Method for logging out
  static Future<void> logout() async {
    await _auth.signOut();
    await _googleSignIn.signOut();
  }

  // New method to get the current logged-in user
  static User? getCurrentUser() {
    return _auth.currentUser;
  }
}
