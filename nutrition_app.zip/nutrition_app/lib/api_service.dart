import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'auth_service.dart';

class ApiService {
  static const String baseUrl = 'https://firstly-popular-bunny.ngrok-free.app';

  // Method to save the token to SharedPreferences
  static Future<void> _saveToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('jwt_token', token);
  }

  // Signup method
  static Future<bool> signup(
      String name,
      String email,
      String password,
      int age,
      String gender,
      double height,
      double weight) async {
    final response = await http.post(
      Uri.parse('$baseUrl/signup'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'name': name,
        'email': email,
        'password': password,
        'age': age,
        'gender': gender,
        'height': height,
        'weight': weight,
      }),
    );

    if (response.statusCode == 201) {
      return true;
    } else {
      print("Signup failed: ${response.body}");
      return false;
    }
  }

  // Login method with token storage
  static Future<bool> login(String email, String password) async {
    final response = await http.post(
      Uri.parse('$baseUrl/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password}),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      String token = data['access_token'];
      String refreshToken = data['refresh_token'];
      await _saveToken(token); // Save access token to SharedPreferences
      await _saveRefreshToken(refreshToken); // Save refresh token
      return true;
    } else {
      return false;
    }
  }

  // Fetch caloric needs with token included in the headers
  static Future<Map<String, dynamic>> fetchCaloricNeeds() async {
    String? token = await _getToken(); // Retrieve token

    if (token == null) {
      throw Exception('No token found. Please log in again.');
    }

    final response = await http.get(
      Uri.parse('$baseUrl/caloric_needs'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else if (response.statusCode == 401) {
      // Token expired, try to refresh
      bool refreshed = await _refreshToken();
      if (refreshed) {
        return fetchCaloricNeeds(); // Retry with new token
      } else {
        throw Exception('Failed to refresh token. Please log in again.');
      }
    } else {
      throw Exception('Failed to fetch caloric needs');
    }
  }

  // Optional: A logout method to clear the token
  static Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('jwt_token');
    await prefs.remove('refresh_token'); // Clear refresh token as well
  }

  // Method to retrieve the access token from SharedPreferences
  static Future<String?> _getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('jwt_token');
  }

  // Method to save the refresh token to SharedPreferences
  static Future<void> _saveRefreshToken(String refreshToken) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('refresh_token', refreshToken);
  }

  // Method to get the refresh token from SharedPreferences
  static Future<String?> _getRefreshToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('refresh_token');
  }

  // Refresh token method
  static Future<bool> _refreshToken() async {
    String? refreshToken = await _getRefreshToken();

    if (refreshToken == null) {
      return false;
    }

    final response = await http.post(
      Uri.parse('$baseUrl/refresh'),
      headers: {'Authorization': 'Bearer $refreshToken'},
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      String newAccessToken = data['access_token'];
      await _saveToken(newAccessToken);
      return true;
    } else {
      print("Failed to refresh token: ${response.body}");
      return false;
    }
  }
}
