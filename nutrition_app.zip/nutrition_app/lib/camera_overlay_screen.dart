import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

class CameraOverlayScreen extends StatefulWidget {
  @override
  _CameraOverlayScreenState createState() => _CameraOverlayScreenState();
}

class _CameraOverlayScreenState extends State<CameraOverlayScreen> {
  String calorieMessage = '';
  bool hasCaptured = false;
  final ImagePicker _picker = ImagePicker();
  XFile? _imageFile;
  int selectedServingSize = 1; // Default serving size

  Future<void> captureImage() async {
    _imageFile = await _picker.pickImage(source: ImageSource.camera);
    if (_imageFile != null) {
      setState(() {
        hasCaptured = true;
        calorieMessage = ''; // Reset the calorie message after each capture
      });
    }
  }

  Future<void> estimateCalories() async {
    if (_imageFile == null) return;

    final bytes = await File(_imageFile!.path).readAsBytes();
    final base64Image = base64Encode(bytes);

    final response = await http.post(
      Uri.parse('https://firstly-popular-bunny.ngrok-free.app/predict'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'image': base64Image,
        'serving_size': selectedServingSize, // Send selected serving size to backend
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      setState(() {
        calorieMessage = 'Detected ${data['predicted_class']} - Estimated Calories: ${data['calories']} kcal';
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to estimate calories: ${response.body}')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Capture and Estimate Calories"),
          automaticallyImplyLeading: true),
      body: Center(
        child: hasCaptured
            ? Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Select Serving Size:", style: TextStyle(fontSize: 18)),
            DropdownButton<int>(
              value: selectedServingSize,
              items: List.generate(5, (index) => index + 1) // Options: 1-5 servings
                  .map((size) => DropdownMenuItem(
                value: size,
                child: Text('$size serving${size > 1 ? 's' : ''}'),
              ))
                  .toList(),
              onChanged: (value) {
                setState(() {
                  selectedServingSize = value!;
                });
              },
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: estimateCalories,
              child: Text("Calculate Calories"),
            ),
            if (calorieMessage.isNotEmpty)
              Container(
                padding: EdgeInsets.all(16.0),
                margin: EdgeInsets.only(top: 20.0),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.9),
                  borderRadius: BorderRadius.circular(12.0),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black26,
                      offset: Offset(0, 4),
                      blurRadius: 8.0,
                    ),
                  ],
                ),
                child: Text(
                  calorieMessage,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  hasCaptured = false;
                  calorieMessage = '';
                  selectedServingSize = 1;
                });
              },
              child: Text("Capture Again"),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: Text("Exit"),
            ),
          ],
        )
            : ElevatedButton(
          onPressed: captureImage,
          child: Text("Capture Image"),
        ),
      ),
    );
  }
}
