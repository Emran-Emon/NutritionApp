package com.example.nutrition_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
